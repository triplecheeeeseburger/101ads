import Foundation
import CoreLocation
import UIKit

// MARK: - Billboard Model
struct Billboard: Identifiable, Codable, Equatable {
    var id: UUID
    var latitude: Double
    var longitude: Double
    var ocrText: String
    var category: String
    var imageLocalPath: String?
    var imageRemoteURL: String?
    var capturedAt: Date
    var uploadStatus: UploadStatus
    var address: String?
    var companyName: String?
    var companyURL: String?
    var companyLogoURL: String?

    enum UploadStatus: String, Codable {
        case pending, uploading, uploaded, failed
    }

    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }

    init(
        id: UUID = UUID(),
        latitude: Double,
        longitude: Double,
        ocrText: String = "",
        category: String = "Uncategorized",
        imageLocalPath: String? = nil,
        imageRemoteURL: String? = nil,
        capturedAt: Date = Date(),
        uploadStatus: UploadStatus = .pending,
        address: String? = nil,
        companyName: String? = nil,
        companyURL: String? = nil,
        companyLogoURL: String? = nil
    ) {
        self.id = id
        self.latitude = latitude
        self.longitude = longitude
        self.ocrText = ocrText
        self.category = category
        self.imageLocalPath = imageLocalPath
        self.imageRemoteURL = imageRemoteURL
        self.capturedAt = capturedAt
        self.uploadStatus = uploadStatus
        self.address = address
        self.companyName = companyName
        self.companyURL = companyURL
        self.companyLogoURL = companyLogoURL
    }
}

// MARK: - Ad Category
enum AdCategory: String, CaseIterable {
    case ai = "AI & Tech"
    case pharma = "Pharma & Health"
    case finance = "Finance"
    case realEstate = "Real Estate"
    case entertainment = "Entertainment"
    case food = "Food & Beverage"
    case automotive = "Automotive"
    case education = "Education"
    case government = "Government & Public"
    case retail = "Retail"
    case other = "Other"
    case uncategorized = "Uncategorized"

    var emoji: String {
        switch self {
        case .ai: return "🤖"
        case .pharma: return "💊"
        case .finance: return "💰"
        case .realEstate: return "🏠"
        case .entertainment: return "🎬"
        case .food: return "🍔"
        case .automotive: return "🚗"
        case .education: return "📚"
        case .government: return "🏛️"
        case .retail: return "🛍️"
        case .other: return "📌"
        case .uncategorized: return "❓"
        }
    }
}

// MARK: - Supabase DTO
struct BillboardDTO: Codable {
    let id: String
    let latitude: Double
    let longitude: Double
    let ocr_text: String
    let category: String
    let image_url: String?
    let captured_at: String
    let address: String?
    let company_name: String?
    let company_url: String?
    let company_logo_url: String?
}

// MARK: - Claude enrichment response
struct BillboardEnrichment {
    let category: String
    let companyName: String?
    let companyURL: String?
    let companyLogoURL: String?
}
