import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var supabaseService: SupabaseService
    @AppStorage("supabase_url") private var supabaseURL = "https://ewjnpoziinaprmkxjnhu.supabase.co"
    @AppStorage("supabase_key") private var supabaseKey = "sb_publishable_9TACfIEqKqnNETuV_P0YZw_uohUpV9c"
    @AppStorage("anthropic_key") private var anthropicKey = ""
    @AppStorage("auto_capture_enabled") private var autoCaptureEnabled = true
    @AppStorage("capture_confidence") private var captureConfidence = 0.85
    @State private var showingClearAlert = false
    @State private var showingSyncSuccess = false
    
    var body: some View {
        NavigationView {
            Form {
                // API Keys
                Section {
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Supabase Project URL", systemImage: "server.rack")
                            .font(.caption)
                            .foregroundColor(.gray)
                        TextField("https://xxx.supabase.co", text: $supabaseURL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .font(.caption)
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Supabase Anon Key", systemImage: "key.fill")
                            .font(.caption)
                            .foregroundColor(.gray)
                        SecureField("eyJhbGci...", text: $supabaseKey)
                            .textInputAutocapitalization(.never)
                            .font(.caption)
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Anthropic API Key", systemImage: "brain")
                            .font(.caption)
                            .foregroundColor(.gray)
                        SecureField("sk-ant-...", text: $anthropicKey)
                            .textInputAutocapitalization(.never)
                            .font(.caption)
                    }
                } header: {
                    Text("API Configuration")
                } footer: {
                    Text("Keys are stored securely on device only.")
                }
                
                // Detection Settings
                Section {
                    Toggle(isOn: $autoCaptureEnabled) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Auto-Capture")
                                .font(.body)
                            Text(autoCaptureEnabled ? "Captures automatically when billboard detected" : "Manual only — tap shutter button")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                    }
                    .tint(.orange)

                    if autoCaptureEnabled {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("Sensitivity")
                                Spacer()
                                Text("\(Int(captureConfidence * 100))%")
                                    .foregroundColor(.orange)
                                    .bold()
                                    .frame(width: 44, alignment: .trailing)
                            }
                            Slider(value: $captureConfidence, in: 0.60...0.95, step: 0.05)
                                .tint(.orange)
                            HStack {
                                Text("More captures")
                                    .font(.caption2).foregroundColor(.gray)
                                Spacer()
                                Text("Fewer false positives")
                                    .font(.caption2).foregroundColor(.gray)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                } header: {
                    Text("Detection")
                } footer: {
                    Text("Recommended: 80-85%. Frame processing runs at ~4fps to preserve battery.")
                }
                
                // Data Management
                Section("Data") {
                    HStack {
                        Text("Total Billboards")
                        Spacer()
                        Text("\(supabaseService.billboards.count)")
                            .foregroundColor(.gray)
                    }
                    
                    HStack {
                        Text("Pending Upload")
                        Spacer()
                        Text("\(supabaseService.pendingCount)")
                            .foregroundColor(supabaseService.pendingCount > 0 ? .orange : .gray)
                    }
                    
                    Button(action: {
                        Task { await supabaseService.fetchFromRemote() }
                        showingSyncSuccess = true
                    }) {
                        Label("Sync from Supabase", systemImage: "arrow.triangle.2.circlepath")
                    }
                    .tint(.blue)
                    
                    Button(action: { supabaseService.retryFailed() }) {
                        Label("Retry Failed Uploads", systemImage: "arrow.up.circle")
                    }
                    .tint(.orange)
                    
                    Button(role: .destructive, action: { showingClearAlert = true }) {
                        Label("Clear All Local Data", systemImage: "trash")
                    }
                }
                

                // Connection Diagnostics
                Section {
                    Button(action: {
                        Task { await supabaseService.runDiagnostics() }
                    }) {
                        HStack {
                            if supabaseService.isTesting {
                                ProgressView()
                                    .scaleEffect(0.8)
                                    .padding(.trailing, 4)
                                Text("Testing connections…")
                                    .foregroundColor(.gray)
                            } else {
                                Label("Test Connection", systemImage: "antenna.radiowaves.left.and.right")
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                    .disabled(supabaseService.isTesting)
                    
                    if supabaseService.diagResult.dbStatus != .idle {
                        DiagRow(label: "Database", status: supabaseService.diagResult.dbStatus, message: supabaseService.diagResult.dbMessage)
                        DiagRow(label: "Storage Bucket", status: supabaseService.diagResult.storageStatus, message: supabaseService.diagResult.storageMessage)
                        DiagRow(label: "Claude API", status: supabaseService.diagResult.claudeStatus, message: supabaseService.diagResult.claudeMessage)
                    }
                } header: {
                    Text("Diagnostics")
                } footer: {
                    Text("Tests live connectivity to Supabase DB, Storage bucket, and Anthropic API.")
                }
                
                // Supabase Setup Guide
                Section("Setup Guide") {
                    Link(destination: URL(string: "https://supabase.com/dashboard")!) {
                        Label("Open Supabase Dashboard", systemImage: "arrow.up.right.square")
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Required Supabase SQL:")
                            .font(.caption.bold())
                        Text("""
CREATE TABLE billboards (
  id uuid PRIMARY KEY,
  latitude float8 NOT NULL,
  longitude float8 NOT NULL,
  ocr_text text,
  category text,
  image_url text,
  captured_at timestamptz,
  address text
);

-- Enable storage bucket
-- Create bucket named: billboards (public)
""")
                        .font(.system(.caption2, design: .monospaced))
                        .foregroundColor(.gray)
                        .padding(8)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                    }
                }
                
                Section {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("1.0.0")
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Text("Built for")
                        Spacer()
                        Text("Highway 101, Bay Area 🌉")
                            .foregroundColor(.gray)
                            .font(.caption)
                    }
                }
            }
            .navigationTitle("Settings")
            .alert("Clear Data", isPresented: $showingClearAlert) {
                Button("Clear", role: .destructive) {
                    UserDefaults.standard.removeObject(forKey: "saved_billboards")
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will remove all locally saved billboard data. Uploaded data in Supabase will not be affected.")
            }
            .alert("Sync Complete", isPresented: $showingSyncSuccess) {
                Button("OK", role: .cancel) {}
            }
        }
    }
}

// MARK: - Diag Row Helper
struct DiagRow: View {
    let label: String
    let status: SupabaseService.DiagStatus
    let message: String
    
    var icon: String {
        switch status {
        case .idle: return "circle"
        case .testing: return "circle.dotted"
        case .ok: return "checkmark.circle.fill"
        case .fail: return "xmark.circle.fill"
        }
    }
    
    var color: Color {
        switch status {
        case .idle, .testing: return .gray
        case .ok: return .green
        case .fail: return .red
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 6) {
                if status == .testing {
                    ProgressView().scaleEffect(0.7)
                } else {
                    Image(systemName: icon).foregroundColor(color)
                }
                Text(label).font(.subheadline).bold()
            }
            if !message.isEmpty {
                Text(message)
                    .font(.caption)
                    .foregroundColor(status == .fail ? .red : .gray)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 2)
    }
}
