import SwiftUI

struct ContentView: View {
    @EnvironmentObject var supabaseService: SupabaseService
    @StateObject private var cameraService = CameraService()
    @StateObject private var locationService = LocationService()
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            CameraView(cameraService: cameraService, locationService: locationService)
                .tabItem {
                    Label("Scan", systemImage: "camera.fill")
                }
                .tag(0)
            
            GalleryView()
                .tabItem {
                    Label("Gallery", systemImage: "photo.stack.fill")
                }
                .tag(1)
            
            StatsView()
                .tabItem {
                    Label("Stats", systemImage: "chart.bar.fill")
                }
                .tag(2)
            
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gearshape.fill")
                }
                .tag(3)
        }
        .accentColor(.orange)
        .onAppear {
            cameraService.locationService = locationService
            cameraService.checkPermissions()
        }
        .onChange(of: cameraService.capturedBillboard) { billboard in
            if let billboard = billboard {
                supabaseService.save(billboard)
                let generator = UINotificationFeedbackGenerator()
                generator.notificationOccurred(.success)
            }
        }
    }
}
