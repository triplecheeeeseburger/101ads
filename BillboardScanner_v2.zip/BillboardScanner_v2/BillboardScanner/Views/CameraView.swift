import SwiftUI
import AVFoundation

// MARK: - Camera View
struct CameraView: View {
    @ObservedObject var cameraService: CameraService
    @ObservedObject var locationService: LocationService
    @EnvironmentObject var supabaseService: SupabaseService
    @State private var showCaptureFeedback = false

    var body: some View {
        ZStack {
            // ── Camera preview (always fills screen) ──────────────────
            if let layer = cameraService.previewLayer {
                CameraPreviewView(previewLayer: layer,
                                  onOrientationChange: { orientation in
                    cameraService.updateOrientation(orientation)
                })
                .ignoresSafeArea()
            } else {
                Color.black.ignoresSafeArea()
            }

            // ── Detection bounding box overlay ────────────────────────
            GeometryReader { geo in
                if cameraService.isDetectingBillboard && cameraService.detectedRect != .zero {
                    let rect = cameraService.detectedRect
                    RoundedRectangle(cornerRadius: 4)
                        .stroke(confidenceColor(cameraService.detectionConfidence), lineWidth: 3)
                        .frame(width: rect.width * geo.size.width,
                               height: rect.height * geo.size.height)
                        .position(x: rect.midX * geo.size.width,
                                  y: rect.midY * geo.size.height)
                        .animation(.easeInOut(duration: 0.1), value: rect)
                }
            }

            // ── HUD ───────────────────────────────────────────────────
            VStack(spacing: 0) {
                // Top bar
                HStack(alignment: .center) {
                    // GPS
                    HStack(spacing: 4) {
                        Image(systemName: "location.fill")
                            .foregroundColor(locationService.accuracy < 20 ? .green : .yellow)
                            .font(.caption)
                        Text(String(format: "%.4f, %.4f",
                                    locationService.currentCoordinate.latitude,
                                    locationService.currentCoordinate.longitude))
                            .font(.caption2)
                            .foregroundColor(.white)
                    }
                    .hudStyle()

                    Spacer()

                    // Pending uploads
                    if supabaseService.pendingCount > 0 {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.up.circle.fill")
                                .foregroundColor(.orange).font(.caption)
                            Text("\(supabaseService.pendingCount) pending")
                                .font(.caption2).foregroundColor(.white)
                        }
                        .hudStyle()
                    }

                    // Capture count
                    HStack(spacing: 4) {
                        Image(systemName: "photo.stack.fill")
                            .foregroundColor(.orange).font(.caption)
                        Text("\(supabaseService.billboards.count)")
                            .font(.caption2.bold()).foregroundColor(.white)
                    }
                    .hudStyle()
                }
                .padding(.horizontal, 16)
                .padding(.top, 16)

                Spacer()

                // Confidence bar
                if cameraService.detectionConfidence > 0.3 {
                    VStack(spacing: 4) {
                        Text(detectionLabel(cameraService.detectionConfidence))
                            .font(.caption.bold())
                            .foregroundColor(confidenceColor(cameraService.detectionConfidence))
                        ProgressView(value: Double(cameraService.detectionConfidence))
                            .progressViewStyle(LinearProgressViewStyle(
                                tint: confidenceColor(cameraService.detectionConfidence)))
                            .frame(width: 200)
                    }
                    .padding(.bottom, 8)
                }

                // ── Bottom controls ────────────────────────────────────
                HStack(spacing: 0) {
                    // Left: last captured thumbnail
                    Group {
                        if let last = supabaseService.billboards.first,
                           let path = last.imageLocalPath,
                           let img  = UIImage(contentsOfFile: path) {
                            Image(uiImage: img)
                                .resizable().scaledToFill()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white, lineWidth: 2))
                        } else {
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white.opacity(0.2))
                                .frame(width: 56, height: 56)
                        }
                    }
                    .frame(maxWidth: .infinity)

                    // Centre: shutter
                    Button(action: {
                        cameraService.capturePhoto()
                        triggerFeedback()
                    }) {
                        ZStack {
                            Circle().stroke(Color.white, lineWidth: 3).frame(width: 72, height: 72)
                            Circle().fill(Color.white).frame(width: 60, height: 60)
                        }
                    }
                    .frame(maxWidth: .infinity)

                    // Right: zoom + auto indicator
                    VStack(spacing: 8) {
                        // Zoom toggle button
                        Button(action: { cameraService.toggleZoom() }) {
                            Text(cameraService.zoomFactor > 1.5 ? "3×" : "1×")
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundColor(cameraService.zoomFactor > 1.5 ? .yellow : .white)
                                .frame(width: 36, height: 36)
                                .background(Color.black.opacity(0.5))
                                .clipShape(Circle())
                                .overlay(Circle().stroke(
                                    cameraService.zoomFactor > 1.5 ? Color.yellow : Color.white.opacity(0.5),
                                    lineWidth: 1.5))
                        }

                        // Auto mode indicator
                        let autoOn = UserDefaults.standard.object(forKey: "auto_capture_enabled") as? Bool ?? true
                        Image(systemName: autoOn ? "bolt.fill" : "bolt.slash.fill")
                            .foregroundColor(autoOn ? .yellow : .gray)
                            .font(.caption)
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.vertical, 20)
                .padding(.bottom, 24)
                .background(Color.black.opacity(0.4))
            }

            // ── Flash feedback ─────────────────────────────────────────
            if showCaptureFeedback {
                Color.white.opacity(0.55).ignoresSafeArea().allowsHitTesting(false)
            }
        }
        // Keep the SwiftUI view portrait — camera layer handles its own rotation
        .onChange(of: cameraService.capturedBillboard) { _ in triggerFeedback() }
        .alert("Camera Access Required", isPresented: $cameraService.permissionDenied) {
            Button("Open Settings") {
                UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
            }
            Button("Cancel", role: .cancel) {}
        }
    }

    private func triggerFeedback() {
        withAnimation(.easeIn(duration: 0.08)) { showCaptureFeedback = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            withAnimation { showCaptureFeedback = false }
        }
    }

    private func confidenceColor(_ c: Float) -> Color {
        c > 0.85 ? .green : c > 0.7 ? .yellow : .orange
    }

    private func detectionLabel(_ c: Float) -> String {
        c > 0.85 ? "📸 Billboard detected — capturing!" :
        c > 0.7  ? "🔍 Possible billboard..." : "👀 Scanning..."
    }
}

// MARK: - HUD pill modifier
private extension View {
    func hudStyle() -> some View {
        self.padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.black.opacity(0.6))
            .cornerRadius(8)
    }
}

// MARK: - Camera Preview (UIViewRepresentable)
// Observes device orientation via UIDevice notifications and forwards to CameraService.
// The SwiftUI app stays portrait-locked; only the preview layer connection rotates.
struct CameraPreviewView: UIViewRepresentable {
    let previewLayer: AVCaptureVideoPreviewLayer
    let onOrientationChange: (UIDeviceOrientation) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .black
        previewLayer.frame = view.bounds
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)

        // Start listening for device rotation
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
        NotificationCenter.default.addObserver(
            context.coordinator,
            selector: #selector(Coordinator.orientationChanged),
            name: UIDevice.orientationDidChangeNotification,
            object: nil
        )
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        DispatchQueue.main.async {
            self.previewLayer.frame = uiView.bounds
        }
    }

    static func dismantleUIView(_ uiView: UIView, coordinator: Coordinator) {
        UIDevice.current.endGeneratingDeviceOrientationNotifications()
        NotificationCenter.default.removeObserver(coordinator)
    }

    // MARK: Coordinator
    class Coordinator: NSObject {
        let parent: CameraPreviewView
        init(_ parent: CameraPreviewView) { self.parent = parent }

        @objc func orientationChanged() {
            let orientation = UIDevice.current.orientation
            guard orientation.isValidInterfaceOrientation || orientation.isLandscape else { return }

            // Update preview layer videoOrientation so it fills correctly
            let avOrientation: AVCaptureVideoOrientation
            switch orientation {
            case .landscapeLeft:         avOrientation = .landscapeRight
            case .landscapeRight:        avOrientation = .landscapeLeft
            case .portraitUpsideDown:    avOrientation = .portraitUpsideDown
            default:                     avOrientation = .portrait
            }

            DispatchQueue.main.async {
                self.parent.previewLayer.connection?.videoOrientation = avOrientation
            }

            // Tell CameraService so it can rotate the video output connection too
            parent.onOrientationChange(orientation)
        }
    }
}
