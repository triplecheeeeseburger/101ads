import SwiftUI

struct StatsView: View {
    @EnvironmentObject var supabaseService: SupabaseService
    
    var categoryCounts: [(String, Int)] {
        var counts: [String: Int] = [:]
        for billboard in supabaseService.billboards {
            counts[billboard.category, default: 0] += 1
        }
        return counts.sorted { $0.value > $1.value }
    }
    
    var totalBillboards: Int { supabaseService.billboards.count }
    var uploadedCount: Int { supabaseService.billboards.filter { $0.uploadStatus == .uploaded }.count }
    var pendingCount: Int { supabaseService.billboards.filter { $0.uploadStatus == .pending }.count }
    
    var recentBillboards: [Billboard] {
        let calendar = Calendar.current
        let weekAgo = calendar.date(byAdding: .day, value: -7, to: Date())!
        return supabaseService.billboards.filter { $0.capturedAt > weekAgo }
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    
                    // Summary Cards
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        StatCard(title: "Total", value: "\(totalBillboards)", icon: "billboard.fill", color: .orange)
                        StatCard(title: "This Week", value: "\(recentBillboards.count)", icon: "calendar", color: .blue)
                        StatCard(title: "Uploaded", value: "\(uploadedCount)", icon: "checkmark.icloud.fill", color: .green)
                        StatCard(title: "Pending", value: "\(pendingCount)", icon: "clock.fill", color: .yellow)
                    }
                    .padding(.horizontal)
                    
                    // Category Breakdown
                    if !categoryCounts.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("By Category")
                                .font(.headline)
                                .padding(.horizontal)
                            
                            VStack(spacing: 8) {
                                ForEach(categoryCounts, id: \.0) { category, count in
                                    CategoryBar(
                                        category: category,
                                        count: count,
                                        total: totalBillboards
                                    )
                                }
                            }
                            .padding(.horizontal)
                        }
                        .padding(.vertical)
                        .background(Color(.systemBackground))
                        .cornerRadius(16)
                        .shadow(color: .black.opacity(0.05), radius: 8)
                        .padding(.horizontal)
                    }
                    
                    // Top OCR Text snippets
                    if !supabaseService.billboards.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Recent Captures")
                                .font(.headline)
                            
                            ForEach(supabaseService.billboards.prefix(5)) { billboard in
                                HStack(alignment: .top, spacing: 12) {
                                    // Thumbnail
                                    if let path = billboard.imageLocalPath, let img = UIImage(contentsOfFile: path) {
                                        Image(uiImage: img)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 48, height: 48)
                                            .clipShape(RoundedRectangle(cornerRadius: 8))
                                    } else {
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(Color(.systemGray5))
                                            .frame(width: 48, height: 48)
                                    }
                                    
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(billboard.category)
                                            .font(.caption.bold())
                                            .foregroundColor(.orange)
                                        Text(billboard.ocrText.isEmpty ? "No text detected" : billboard.ocrText)
                                            .font(.caption)
                                            .lineLimit(2)
                                            .foregroundColor(.secondary)
                                        Text(billboard.capturedAt, style: .relative)
                                            .font(.caption2)
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                }
                                .padding(.vertical, 4)
                                
                                if billboard.id != supabaseService.billboards.prefix(5).last?.id {
                                    Divider()
                                }
                            }
                        }
                        .padding()
                        .background(Color(.systemBackground))
                        .cornerRadius(16)
                        .shadow(color: .black.opacity(0.05), radius: 8)
                        .padding(.horizontal)
                    }
                    
                    if totalBillboards == 0 {
                        VStack(spacing: 16) {
                            Image(systemName: "chart.bar.xaxis")
                                .font(.system(size: 48))
                                .foregroundColor(.gray)
                            Text("No data yet")
                                .font(.headline)
                                .foregroundColor(.gray)
                            Text("Start capturing billboards to see statistics here")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                        }
                        .padding(.top, 60)
                    }
                    
                    Spacer(minLength: 40)
                }
                .padding(.top)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Statistics")
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                Spacer()
            }
            Text(value)
                .font(.system(size: 32, weight: .bold, design: .rounded))
            Text(title)
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4)
    }
}

struct CategoryBar: View {
    let category: String
    let count: Int
    let total: Int
    
    var percentage: Double {
        total > 0 ? Double(count) / Double(total) : 0
    }
    
    var emoji: String {
        AdCategory(rawValue: category)?.emoji ?? "📌"
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text("\(emoji) \(category)")
                    .font(.caption.bold())
                Spacer()
                Text("\(count) (\(Int(percentage * 100))%)")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color(.systemGray5))
                        .frame(height: 8)
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color.orange)
                        .frame(width: geo.size.width * percentage, height: 8)
                }
            }
            .frame(height: 8)
        }
    }
}
