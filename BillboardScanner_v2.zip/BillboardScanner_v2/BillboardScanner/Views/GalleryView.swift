import SwiftUI

struct GalleryView: View {
    @EnvironmentObject var supabaseService: SupabaseService
    @State private var selectedCategory: String = "All"
    @State private var selectedBillboard: Billboard?
    @State private var searchText = ""
    
    var categories: [String] {
        var cats = ["All"]
        cats += Array(Set(supabaseService.billboards.map { $0.category })).sorted()
        return cats
    }
    
    var filtered: [Billboard] {
        supabaseService.billboards.filter { billboard in
            let matchesCategory = selectedCategory == "All" || billboard.category == selectedCategory
            let matchesSearch = searchText.isEmpty ||
                billboard.ocrText.localizedCaseInsensitiveContains(searchText) ||
                billboard.category.localizedCaseInsensitiveContains(searchText) ||
                (billboard.address ?? "").localizedCaseInsensitiveContains(searchText)
            return matchesCategory && matchesSearch
        }
    }
    
    let columns = [GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Search bar
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    TextField("Search billboards...", text: $searchText)
                }
                .padding(10)
                .background(Color(.systemGray6))
                .cornerRadius(10)
                .padding(.horizontal)
                .padding(.top, 8)
                
                // Category filter chips
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(categories, id: \.self) { category in
                            Button(action: { selectedCategory = category }) {
                                Text(category)
                                    .font(.caption.bold())
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(selectedCategory == category ? Color.orange : Color(.systemGray5))
                                    .foregroundColor(selectedCategory == category ? .white : .primary)
                                    .cornerRadius(20)
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                }
                
                if filtered.isEmpty {
                    Spacer()
                    VStack(spacing: 12) {
                        Image(systemName: "photo.stack")
                            .font(.system(size: 48))
                            .foregroundColor(.gray)
                        Text("No billboards yet")
                            .font(.headline)
                            .foregroundColor(.gray)
                        Text("Drive along Hwy 101 and let the app auto-detect billboards")
                            .font(.caption)
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }
                    Spacer()
                } else {
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 12) {
                            ForEach(filtered) { billboard in
                                BillboardCard(billboard: billboard)
                                    .onTapGesture { selectedBillboard = billboard }
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Billboards (\(filtered.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        Task { await supabaseService.fetchFromRemote() }
                    }) {
                        Image(systemName: supabaseService.isSyncing ? "arrow.triangle.2.circlepath" : "arrow.down.circle")
                            .rotationEffect(supabaseService.isSyncing ? .degrees(360) : .degrees(0))
                            .animation(supabaseService.isSyncing ? .linear(duration: 1).repeatForever(autoreverses: false) : .default, value: supabaseService.isSyncing)
                    }
                }
            }
            .sheet(item: $selectedBillboard) { billboard in
                BillboardDetailView(billboard: billboard)
            }
        }
    }
}

// MARK: - Billboard Card
struct BillboardCard: View {
    let billboard: Billboard
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Image
            ZStack(alignment: .topTrailing) {
                if let path = billboard.imageLocalPath, let img = UIImage(contentsOfFile: path) {
                    Image(uiImage: img)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 110)
                        .clipped()
                } else {
                    Rectangle()
                        .fill(Color(.systemGray5))
                        .frame(height: 110)
                        .overlay(
                            Image(systemName: "photo")
                                .foregroundColor(.gray)
                        )
                }
                
                // Upload status indicator
                Circle()
                    .fill(statusColor(billboard.uploadStatus))
                    .frame(width: 10, height: 10)
                    .padding(6)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                // Category badge
                Text(billboard.category)
                    .font(.caption2.bold())
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .background(Color.orange.opacity(0.15))
                    .foregroundColor(.orange)
                    .cornerRadius(4)
                
                // OCR text preview
                if !billboard.ocrText.isEmpty {
                    Text(billboard.ocrText)
                        .font(.caption)
                        .lineLimit(2)
                        .foregroundColor(.secondary)
                }
                
                // Address
                if let address = billboard.address {
                    Text(address)
                        .font(.caption2)
                        .foregroundColor(.gray)
                        .lineLimit(1)
                }
                
                // Timestamp
                Text(billboard.capturedAt, style: .relative)
                    .font(.caption2)
                    .foregroundColor(.gray)
            }
            .padding(8)
        }
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.08), radius: 4, x: 0, y: 2)
    }
    
    private func statusColor(_ status: Billboard.UploadStatus) -> Color {
        switch status {
        case .uploaded: return .green
        case .uploading: return .blue
        case .pending: return .orange
        case .failed: return .red
        }
    }
}

// MARK: - Detail View
struct BillboardDetailView: View {
    let billboard: Billboard
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var supabaseService: SupabaseService
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Image
                    if let path = billboard.imageLocalPath, let img = UIImage(contentsOfFile: path) {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(12)
                    }
                    
                    // Category
                    HStack {
                        Text(billboard.category)
                            .font(.headline)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                        Spacer()
                        Text(billboard.capturedAt, style: .date)
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    
                    // OCR Text
                    if !billboard.ocrText.isEmpty {
                        VStack(alignment: .leading, spacing: 6) {
                            Label("Detected Text", systemImage: "text.viewfinder")
                                .font(.caption.bold())
                                .foregroundColor(.gray)
                            Text(billboard.ocrText)
                                .font(.body)
                                .padding()
                                .background(Color(.systemGray6))
                                .cornerRadius(8)
                        }
                    }
                    
                    // Location
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Location", systemImage: "mappin.circle.fill")
                            .font(.caption.bold())
                            .foregroundColor(.gray)
                        if let address = billboard.address {
                            Text(address).font(.body)
                        }
                        Text(String(format: "%.6f, %.6f", billboard.latitude, billboard.longitude))
                            .font(.caption)
                            .foregroundColor(.gray)
                            .padding(.top, 2)
                    }
                    
                    // Upload status
                    HStack {
                        Label("Upload Status", systemImage: "icloud.fill")
                            .font(.caption.bold())
                            .foregroundColor(.gray)
                        Spacer()
                        Text(billboard.uploadStatus.rawValue.capitalized)
                            .font(.caption)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(uploadStatusColor.opacity(0.15))
                            .foregroundColor(uploadStatusColor)
                            .cornerRadius(6)
                    }
                    
                    if billboard.uploadStatus == .failed {
                        Button("Retry Upload") {
                            Task { await supabaseService.uploadBillboard(billboard) }
                        }
                        .buttonStyle(.bordered)
                        .tint(.orange)
                    }
                }
                .padding()
            }
            .navigationTitle("Billboard Detail")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
    
    var uploadStatusColor: Color {
        switch billboard.uploadStatus {
        case .uploaded: return .green
        case .uploading: return .blue
        case .pending: return .orange
        case .failed: return .red
        }
    }
}
