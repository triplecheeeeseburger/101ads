import AVFoundation
import Vision
import UIKit
import CoreLocation
import Combine

// MARK: - Camera Service
class CameraService: NSObject, ObservableObject {

    // MARK: - Published State
    @Published var detectionConfidence: Float = 0.0
    @Published var isDetectingBillboard = false
    @Published var capturedBillboard: Billboard?
    @Published var previewLayer: AVCaptureVideoPreviewLayer?
    @Published var detectedRect: CGRect = .zero
    @Published var isSessionRunning = false
    @Published var permissionDenied = false
    @Published var zoomFactor: CGFloat = 1.0   // 1x or 3x
    @Published var isLandscape: Bool = false

    // MARK: - Settings
    var autoCaptureEnabled: Bool {
        UserDefaults.standard.object(forKey: "auto_capture_enabled") as? Bool ?? true
    }
    var captureConfidenceThreshold: Float {
        Float(UserDefaults.standard.object(forKey: "capture_confidence") as? Double ?? 0.82)
    }

    // MARK: - Private AV objects
    private let captureSession  = AVCaptureSession()
    private let videoOutput     = AVCaptureVideoDataOutput()
    // No AVCapturePhotoOutput — we capture directly from the best video frame
    private let sessionQueue    = DispatchQueue(label: "com.billboardscanner.session")
    private let visionQueue     = DispatchQueue(label: "com.billboardscanner.vision")
    private var videoDevice: AVCaptureDevice?

    // MARK: - Vision
    private var rectangleRequest: VNDetectRectanglesRequest!
    private var textRequest: VNRecognizeTextRequest!

    // MARK: - Capture throttle
    private var lastCaptureTime: Date = .distantPast
    private let minCaptureInterval: TimeInterval = 3.5
    private var frameCounter = 0
    private let frameSkip = 3   // ~10fps detection on 30fps feed

    // MARK: - Best-frame selection
    // Instead of triggering AVCapturePhotoOutput (which shoots a *different* frame),
    // we score sharpness on the video frames themselves and save the sharpest one directly.
    // This means zero lag between "this frame is sharp" and "this is the captured image".
    private var bestCandidate: (image: UIImage, rect: CGRect, score: Float)?
    private var isBuildingCandidates = false
    private var candidateWindowStart: Date = .distantPast
    private let candidateWindowSeconds: TimeInterval = 0.35  // ~3-4 frames at 10fps
    private var captureRect: CGRect = .zero

    var locationService: LocationService?

    override init() {
        super.init()
        setupVision()
    }

    // MARK: - Vision Setup
    private func setupVision() {
        rectangleRequest = VNDetectRectanglesRequest { [weak self] request, error in
            guard let self = self else { return }
            guard let results = request.results as? [VNRectangleObservation],
                  let best = results.first else {
                DispatchQueue.main.async {
                    self.detectionConfidence = 0
                    self.isDetectingBillboard = false
                    self.detectedRect = .zero
                }
                self.isBuildingCandidates = false
                self.bestCandidate = nil
                return
            }

            let confidence  = best.confidence
            let threshold   = self.captureConfidenceThreshold
            let convertedRect = self.convert(rect: best.boundingBox)

            DispatchQueue.main.async {
                self.detectionConfidence = confidence
                self.detectedRect = convertedRect
                self.isDetectingBillboard = confidence > max(threshold - 0.15, 0.5)
            }

            guard self.autoCaptureEnabled else { return }
            guard confidence >= threshold else { return }
            guard Date().timeIntervalSince(self.lastCaptureTime) > self.minCaptureInterval else { return }

            if !self.isBuildingCandidates {
                self.isBuildingCandidates = true
                self.candidateWindowStart = Date()
                self.bestCandidate = nil
            }
        }

        rectangleRequest.minimumAspectRatio  = 1.5
        rectangleRequest.maximumAspectRatio  = 6.0
        rectangleRequest.minimumSize         = 0.12
        rectangleRequest.minimumConfidence   = 0.60
        rectangleRequest.maximumObservations = 1

        textRequest = VNRecognizeTextRequest()
        textRequest.recognitionLevel    = .accurate
        textRequest.usesLanguageCorrection = true
    }

    // MARK: - Session Setup
    func setupSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            self.captureSession.beginConfiguration()
            self.captureSession.sessionPreset = .hd1920x1080  // 1080p for better detail

            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let input  = try? AVCaptureDeviceInput(device: device),
                  self.captureSession.canAddInput(input) else { return }
            self.captureSession.addInput(input)
            self.videoDevice = device

            // Video output — full pixel data, no discarding so we can save frames directly
            self.videoOutput.setSampleBufferDelegate(self, queue: self.visionQueue)
            self.videoOutput.alwaysDiscardsLateVideoFrames = true
            self.videoOutput.videoSettings = [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
            ]
            if self.captureSession.canAddOutput(self.videoOutput) {
                self.captureSession.addOutput(self.videoOutput)
            }

            // Set capture orientation to landscape (billboards are wide)
            if let connection = self.videoOutput.connection(with: .video) {
                if connection.isVideoOrientationSupported {
                    connection.videoOrientation = .landscapeRight
                }
                if connection.isVideoMirroringSupported {
                    connection.isVideoMirrored = false
                }
            }

            self.captureSession.commitConfiguration()

            let layer = AVCaptureVideoPreviewLayer(session: self.captureSession)
            layer.videoGravity = .resizeAspectFill
            DispatchQueue.main.async { self.previewLayer = layer }

            self.captureSession.startRunning()
            DispatchQueue.main.async { self.isSessionRunning = true }
        }
    }

    func checkPermissions() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            setupSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                if granted { self?.setupSession() }
                else { DispatchQueue.main.async { self?.permissionDenied = true } }
            }
        default:
            DispatchQueue.main.async { self.permissionDenied = true }
        }
    }

    func stopSession() {
        sessionQueue.async { [weak self] in
            self?.captureSession.stopRunning()
            DispatchQueue.main.async { self?.isSessionRunning = false }
        }
    }

    // MARK: - Zoom
    // Toggles between 1x and 3x. Uses videoZoomFactor on the device — optical up to 2x
    // on most iPhones, clean digital above that.
    func toggleZoom() {
        let target: CGFloat = zoomFactor == 1.0 ? 3.0 : 1.0
        setZoom(target)
    }

    func setZoom(_ factor: CGFloat) {
        guard let device = videoDevice else { return }
        let clamped = min(max(factor, 1.0), device.activeFormat.videoMaxZoomFactor)
        sessionQueue.async {
            try? device.lockForConfiguration()
            device.ramp(toVideoZoomFactor: clamped, withRate: 8.0)
            device.unlockForConfiguration()
        }
        DispatchQueue.main.async { self.zoomFactor = clamped }
    }

    // MARK: - Orientation
    // Called by the view when device orientation changes.
    // Rotates the preview layer connection so the image fills correctly,
    // while the app UI stays portrait-locked.
    func updateOrientation(_ orientation: UIDeviceOrientation) {
        let isLandscapeNow = orientation.isLandscape
        DispatchQueue.main.async { self.isLandscape = isLandscapeNow }

        guard let connection = videoOutput.connection(with: .video),
              connection.isVideoOrientationSupported else { return }

        let avOrientation: AVCaptureVideoOrientation
        switch orientation {
        case .landscapeLeft:  avOrientation = .landscapeRight   // inverted for rear camera
        case .landscapeRight: avOrientation = .landscapeLeft
        case .portraitUpsideDown: avOrientation = .portraitUpsideDown
        default: avOrientation = .portrait
        }

        sessionQueue.async {
            connection.videoOrientation = avOrientation
            // Also update preview layer
            DispatchQueue.main.async {
                self.previewLayer?.connection?.videoOrientation = avOrientation
            }
        }
    }

    // MARK: - Manual Capture (saves best recent video frame)
    func capturePhoto() {
        guard isSessionRunning else { return }
        // Trigger a one-shot best-frame capture window
        isBuildingCandidates = true
        candidateWindowStart = Date()
        bestCandidate = nil
        // Window will close and save via the video frame delegate
    }

    // MARK: - Save captured frame
    private func commitCapture(_ image: UIImage, rect: CGRect) {
        lastCaptureTime = Date()
        isBuildingCandidates = false
        bestCandidate = nil

        let coordinate = locationService?.currentCoordinate
            ?? CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)

        guard let cgImage = image.cgImage else { return }
        let croppedImage = cropToBillboard(cgImage, using: rect) ?? image
        let ocrText      = extractText(from: croppedImage.cgImage ?? cgImage)
        let path         = saveImageLocally(croppedImage)

        let billboard = Billboard(
            latitude:      coordinate.latitude,
            longitude:     coordinate.longitude,
            ocrText:       ocrText,
            category:      "Uncategorized",
            imageLocalPath: path,
            capturedAt:    Date(),
            uploadStatus:  .pending
        )
        DispatchQueue.main.async { self.capturedBillboard = billboard }
    }

    // MARK: - Sharpness (Laplacian variance on luma channel)
    private func sharpnessScore(of pixelBuffer: CVPixelBuffer) -> Float {
        CVPixelBufferLockBaseAddress(pixelBuffer, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, .readOnly) }

        let width  = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return 0 }

        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
        let ptr = base.assumingMemoryBound(to: UInt8.self)

        // Sample every 4th pixel for speed — BGRA format, luma ≈ G channel (index 1)
        let step = 4
        var sum: Float = 0, sumSq: Float = 0, n: Float = 0
        var y = 0
        while y < height {
            var x = 0
            while x < width {
                let offset = y * bytesPerRow + x * 4
                let luma = Float(ptr[offset + 1])  // G channel
                sum   += luma
                sumSq += luma * luma
                n     += 1
                x += step
            }
            y += step
        }
        guard n > 0 else { return 0 }
        return (sumSq / n) - (sum / n) * (sum / n)  // variance
    }

    // MARK: - Crop + OCR
    private func cropToBillboard(_ cgImage: CGImage, using rect: CGRect) -> UIImage? {
        guard rect != .zero else { return UIImage(cgImage: cgImage) }
        let imageSize = CGSize(width: cgImage.width, height: cgImage.height)
        let padX = rect.width  * 0.12
        let padY = rect.height * 0.12
        let cropRect = CGRect(
            x:      max(0, (rect.origin.x - padX) * imageSize.width),
            y:      max(0, (1 - rect.origin.y - rect.height - padY) * imageSize.height),
            width:  min(imageSize.width,  (rect.width  + padX * 2) * imageSize.width),
            height: min(imageSize.height, (rect.height + padY * 2) * imageSize.height)
        ).integral
        guard let cropped = cgImage.cropping(to: cropRect) else { return UIImage(cgImage: cgImage) }
        return UIImage(cgImage: cropped)
    }

    private func extractText(from cgImage: CGImage) -> String {
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try? handler.perform([textRequest])
        return textRequest.results?
            .compactMap { $0.topCandidates(1).first?.string }
            .joined(separator: " ") ?? ""
    }

    private func saveImageLocally(_ image: UIImage) -> String? {
        guard let data = image.jpegData(compressionQuality: 0.90) else { return nil }
        let filename = "\(UUID().uuidString).jpg"
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(filename)
        try? data.write(to: url)
        return url.path
    }

    private func convert(rect: CGRect) -> CGRect {
        CGRect(x: rect.origin.x, y: 1 - rect.origin.y - rect.height,
               width: rect.width, height: rect.height)
    }
}

// MARK: - Video Frame Delegate
extension CameraService: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        frameCounter += 1
        guard frameCounter % frameSkip == 0 else { return }
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Run rectangle detection on every sampled frame
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer,
                                            orientation: .right, options: [:])
        try? handler.perform([rectangleRequest])

        // If we're in a capture window, score this frame and keep the best
        guard isBuildingCandidates else { return }

        let elapsed = Date().timeIntervalSince(candidateWindowStart)
        let score   = sharpnessScore(of: pixelBuffer)

        if bestCandidate == nil || score > bestCandidate!.score {
            // Convert this pixelBuffer to UIImage immediately — no async gap
            let ciImage  = CIImage(cvPixelBuffer: pixelBuffer)
            let context  = CIContext()
            if let cgImg = context.createCGImage(ciImage, from: ciImage.extent) {
                let uiImg = UIImage(cgImage: cgImg, scale: 1.0, orientation: .right)
                bestCandidate = (image: uiImg, rect: detectedRect, score: score)
            }
        }

        // Close the window when time's up
        if elapsed >= candidateWindowSeconds {
            if let best = bestCandidate {
                let rect = best.rect
                let img  = best.image
                DispatchQueue.global(qos: .userInitiated).async {
                    self.commitCapture(img, rect: rect)
                }
            } else {
                isBuildingCandidates = false
            }
        }
    }
}

// AVCapturePhotoCaptureDelegate stub — kept so Xcode doesn't complain if referenced elsewhere
extension CameraService: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {}
}
