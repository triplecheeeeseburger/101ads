import Foundation
import UIKit

// MARK: - Supabase Service
class SupabaseService: ObservableObject {

    static let shared = SupabaseService()

    // Personal build — keys baked in as defaults so the app works immediately after install.
    private var supabaseURL: String {
        UserDefaults.standard.string(forKey: "supabase_url")
            ?? "https://ewjnpoziinaprmkxjnhu.supabase.co"
    }
    private var supabaseAnonKey: String {
        UserDefaults.standard.string(forKey: "supabase_key")
            ?? "sb_publishable_9TACfIEqKqnNETuV_P0YZw_uohUpV9c"
    }
    private var anthropicKey: String {
        UserDefaults.standard.string(forKey: "anthropic_api_key")
            ?? "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"
    }

    @Published var billboards: [Billboard] = []
    @Published var isSyncing = false
    @Published var pendingCount = 0

    private var localBillboards: [Billboard] = [] {
        didSet {
            DispatchQueue.main.async {
                self.billboards = self.localBillboards
                self.pendingCount = self.localBillboards.filter { $0.uploadStatus == .pending }.count
            }
            saveLocally()
        }
    }

    private let storageKey = "saved_billboards"

    init() { loadLocally() }

    // MARK: - Save
    func save(_ billboard: Billboard) {
        var updated = billboard
        let locationService = LocationService()
        locationService.reverseGeocode(coordinate: billboard.coordinate) { [weak self] address in
            updated.address = address
            self?.localBillboards.append(updated)
            Task { await self?.uploadBillboard(updated) }
        }
    }

    // MARK: - Upload
    func uploadBillboard(_ billboard: Billboard) async {
        guard let index = localBillboards.firstIndex(where: { $0.id == billboard.id }) else { return }
        localBillboards[index].uploadStatus = .uploading

        do {
            // 1. Upload image
            var imageURL: String? = nil
            if let path = billboard.imageLocalPath,
               let image = UIImage(contentsOfFile: path),
               let data = image.jpegData(compressionQuality: 0.88) {
                imageURL = try await uploadImage(data: data, filename: "\(billboard.id).jpg")
            }

            // 2. Single Claude call → category + company name + URL + logo
            let enrichment = await enrichWithClaude(ocrText: billboard.ocrText)

            // 3. Insert record
            let dto = BillboardDTO(
                id:               billboard.id.uuidString,
                latitude:         billboard.latitude,
                longitude:        billboard.longitude,
                ocr_text:         billboard.ocrText,
                category:         enrichment.category,
                image_url:        imageURL,
                captured_at:      ISO8601DateFormatter().string(from: billboard.capturedAt),
                address:          billboard.address,
                company_name:     enrichment.companyName,
                company_url:      enrichment.companyURL,
                company_logo_url: enrichment.companyLogoURL
            )
            try await insertRecord(dto)

            localBillboards[index].uploadStatus    = .uploaded
            localBillboards[index].imageRemoteURL  = imageURL
            localBillboards[index].category        = enrichment.category
            localBillboards[index].companyName     = enrichment.companyName
            localBillboards[index].companyURL      = enrichment.companyURL
            localBillboards[index].companyLogoURL  = enrichment.companyLogoURL

        } catch {
            localBillboards[index].uploadStatus = .failed
            print("Upload failed: \(error)")
        }
    }

    // MARK: - Upload Image
    private func uploadImage(data: Data, filename: String) async throws -> String {
        let urlString = "\(supabaseURL)/storage/v1/object/billboards/\(filename)"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue(supabaseAnonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(supabaseAnonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("image/jpeg", forHTTPHeaderField: "Content-Type")
        request.setValue("true", forHTTPHeaderField: "x-upsert")
        request.httpBody = data
        let (responseData, response) = try await URLSession.shared.data(for: request)
        let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard statusCode == 200 || statusCode == 201 else {
            throw URLError(.badServerResponse)
        }
        return "\(supabaseURL)/storage/v1/object/public/billboards/\(filename)"
    }

    // MARK: - Insert DB Record
    private func insertRecord(_ dto: BillboardDTO) async throws {
        let urlString = "\(supabaseURL)/rest/v1/billboards"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue(supabaseAnonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(supabaseAnonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("return=minimal", forHTTPHeaderField: "Prefer")
        request.httpBody = try JSONEncoder().encode(dto)
        let (_, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 201 else {
            throw URLError(.badServerResponse)
        }
    }

    // MARK: - Claude Enrichment (single call — category + company + URL + logo)
    func enrichWithClaude(ocrText: String) async -> BillboardEnrichment {
        let fallback = BillboardEnrichment(
            category: AdCategory.uncategorized.rawValue,
            companyName: nil, companyURL: nil, companyLogoURL: nil
        )
        guard !ocrText.isEmpty else { return fallback }

        let prompt = """
        Analyze this billboard advertisement text and respond with a JSON object only — no markdown, no explanation.

        Billboard text: "\(ocrText)"

        Return exactly this JSON structure:
        {
          "category": "<one of: AI & Tech, Pharma & Health, Finance, Real Estate, Entertainment, Food & Beverage, Automotive, Education, Government & Public, Retail, Other>",
          "company_name": "<the primary advertiser company name, or null if unclear>",
          "company_url": "<the company's main website URL including https://, or null if unknown>",
          "company_logo_url": "<a Clearbit Logo API URL for this company: https://logo.clearbit.com/<domain> — use the same domain as company_url, or null>"
        }
        """

        guard let url = URL(string: "https://api.anthropic.com/v1/messages") else { return fallback }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        request.setValue(anthropicKey, forHTTPHeaderField: "x-api-key")

        let body: [String: Any] = [
            "model": "claude-haiku-4-5-20251001",
            "max_tokens": 200,
            "messages": [["role": "user", "content": prompt]]
        ]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        guard let (data, _) = try? await URLSession.shared.data(for: request),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let content = (json["content"] as? [[String: Any]])?.first,
              let text = content["text"] as? String,
              let jsonData = text.trimmingCharacters(in: .whitespacesAndNewlines).data(using: .utf8),
              let parsed = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
        else { return fallback }

        let category   = (parsed["category"]          as? String) ?? fallback.category
        let company    = parsed["company_name"]        as? String
        let companyURL = parsed["company_url"]         as? String
        let logoURL    = parsed["company_logo_url"]    as? String

        return BillboardEnrichment(
            category:       category,
            companyName:    company?.isEmpty == false ? company : nil,
            companyURL:     companyURL?.isEmpty == false ? companyURL : nil,
            companyLogoURL: logoURL?.isEmpty == false ? logoURL : nil
        )
    }

    // MARK: - Retry Failed
    func retryFailed() {
        let failed = localBillboards.filter { $0.uploadStatus == .failed }
        for billboard in failed { Task { await uploadBillboard(billboard) } }
    }

    // MARK: - Sync from Remote
    func fetchFromRemote() async {
        DispatchQueue.main.async { self.isSyncing = true }
        let urlString = "\(supabaseURL)/rest/v1/billboards?order=captured_at.desc&limit=500"
        guard let url = URL(string: urlString) else { return }
        var request = URLRequest(url: url)
        request.setValue(supabaseAnonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(supabaseAnonKey)", forHTTPHeaderField: "Authorization")

        guard let (data, _) = try? await URLSession.shared.data(for: request),
              let dtos = try? JSONDecoder().decode([BillboardDTO].self, from: data) else {
            DispatchQueue.main.async { self.isSyncing = false }
            return
        }

        let fetched = dtos.map { dto -> Billboard in
            Billboard(
                id:             UUID(uuidString: dto.id) ?? UUID(),
                latitude:       dto.latitude,
                longitude:      dto.longitude,
                ocrText:        dto.ocr_text,
                category:       dto.category,
                imageRemoteURL: dto.image_url,
                uploadStatus:   .uploaded,
                address:        dto.address,
                companyName:    dto.company_name,
                companyURL:     dto.company_url,
                companyLogoURL: dto.company_logo_url
            )
        }
        DispatchQueue.main.async { self.localBillboards = fetched; self.isSyncing = false }
    }

    // MARK: - Local Persistence
    private func saveLocally() {
        if let data = try? JSONEncoder().encode(localBillboards) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }
    private func loadLocally() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let saved = try? JSONDecoder().decode([Billboard].self, from: data) {
            localBillboards = saved
        }
    }
    func deleteBillboard(_ billboard: Billboard) {
        localBillboards.removeAll { $0.id == billboard.id }
    }

    // MARK: - Diagnostics
    enum DiagStatus { case idle, testing, ok, fail }
    struct DiagResult {
        var dbStatus: DiagStatus = .idle; var storageStatus: DiagStatus = .idle; var claudeStatus: DiagStatus = .idle
        var dbMessage = ""; var storageMessage = ""; var claudeMessage = ""
    }
    @Published var diagResult = DiagResult()
    @Published var isTesting = false

    func runDiagnostics() async {
        DispatchQueue.main.async {
            self.isTesting = true
            self.diagResult = DiagResult(dbStatus: .testing, storageStatus: .testing, claudeStatus: .testing,
                dbMessage: "Testing...", storageMessage: "Testing...", claudeMessage: "Testing...")
        }
        await withTaskGroup(of: Void.self) { group in
            group.addTask { await self.testDatabase() }
            group.addTask { await self.testStorage() }
            group.addTask { await self.testClaudeAPI() }
        }
        DispatchQueue.main.async { self.isTesting = false }
    }

    private func testDatabase() async {
        do {
            let urlString = "\(supabaseURL)/rest/v1/billboards?limit=1"
            guard let url = URL(string: urlString) else { throw URLError(.badURL) }
            var req = URLRequest(url: url)
            req.setValue(supabaseAnonKey, forHTTPHeaderField: "apikey")
            req.setValue("Bearer \(supabaseAnonKey)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: req)
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            if code == 200 {
                let count = (try? JSONDecoder().decode([BillboardDTO].self, from: data))?.count ?? 0
                DispatchQueue.main.async { self.diagResult.dbStatus = .ok; self.diagResult.dbMessage = "✓ Connected · \(count) row(s)" }
            } else {
                let body = String(data: data, encoding: .utf8) ?? ""
                DispatchQueue.main.async { self.diagResult.dbStatus = .fail; self.diagResult.dbMessage = "HTTP \(code): \(body.prefix(120))" }
            }
        } catch {
            DispatchQueue.main.async { self.diagResult.dbStatus = .fail; self.diagResult.dbMessage = error.localizedDescription }
        }
    }

    private func testStorage() async {
        do {
            let urlString = "\(supabaseURL)/storage/v1/bucket/billboards"
            guard let url = URL(string: urlString) else { throw URLError(.badURL) }
            var req = URLRequest(url: url)
            req.setValue(supabaseAnonKey, forHTTPHeaderField: "apikey")
            req.setValue("Bearer \(supabaseAnonKey)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: req)
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            if code == 200 {
                let isPublic = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["public"] as? Bool ?? false
                DispatchQueue.main.async {
                    self.diagResult.storageStatus = .ok
                    self.diagResult.storageMessage = isPublic ? "✓ Bucket exists · Public" : "✓ Bucket exists · ⚠️ Not public"
                }
            } else {
                DispatchQueue.main.async { self.diagResult.storageStatus = .fail; self.diagResult.storageMessage = "HTTP \(code) — bucket may not exist" }
            }
        } catch {
            DispatchQueue.main.async { self.diagResult.storageStatus = .fail; self.diagResult.storageMessage = error.localizedDescription }
        }
    }

    private func testClaudeAPI() async {
        do {
            guard let url = URL(string: "https://api.anthropic.com/v1/messages") else { throw URLError(.badURL) }
            var req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            req.setValue(anthropicKey, forHTTPHeaderField: "x-api-key")
            req.httpBody = try? JSONSerialization.data(withJSONObject: [
                "model": "claude-haiku-4-5-20251001", "max_tokens": 10,
                "messages": [["role": "user", "content": "Hi"]]
            ])
            let (data, response) = try await URLSession.shared.data(for: req)
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            if code == 200 {
                DispatchQueue.main.async { self.diagResult.claudeStatus = .ok; self.diagResult.claudeMessage = "✓ API key valid" }
            } else {
                let body = String(data: data, encoding: .utf8) ?? ""
                DispatchQueue.main.async { self.diagResult.claudeStatus = .fail; self.diagResult.claudeMessage = "HTTP \(code): \(body.prefix(120))" }
            }
        } catch {
            DispatchQueue.main.async { self.diagResult.claudeStatus = .fail; self.diagResult.claudeMessage = error.localizedDescription }
        }
    }
}
