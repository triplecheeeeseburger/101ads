# 🛣️ Billboard Scanner

An iOS app that automatically detects and photographs billboards along Highway 101 in the Bay Area. Uses Apple's Vision framework for real-time billboard detection, on-device OCR, and GPS tagging. Uploads to Supabase with AI-powered categorization via Claude.

---

## Features

- **Auto-detection** — Vision framework detects billboard-shaped rectangles in real time while driving
- **Auto-capture** — Automatically photographs when confidence exceeds threshold (adjustable)
- **On-device OCR** — Extracts text from billboards using Apple's Vision framework (no API needed)
- **GPS tagging** — Stamps every capture with precise coordinates
- **AI categorization** — Sends OCR text to Claude API to classify ad category (AI, Pharma, Finance, etc.)
- **Supabase sync** — Uploads photos and metadata; works offline and syncs when on WiFi
- **Gallery view** — Browse all captured billboards with filters and search
- **Stats dashboard** — Category breakdown, capture counts, recent activity

---

## Setup Instructions

### 1. Supabase Setup

1. Go to [supabase.com](https://supabase.com) and create a free account
2. Create a new project
3. Copy your **Project URL** and **anon key** from Settings > API
4. Run this SQL in the Supabase SQL editor:

```sql
-- Create billboards table
CREATE TABLE billboards (
  id uuid PRIMARY KEY,
  latitude float8 NOT NULL,
  longitude float8 NOT NULL,
  ocr_text text DEFAULT '',
  category text DEFAULT 'Uncategorized',
  image_url text,
  captured_at timestamptz DEFAULT now(),
  address text
);

-- Enable Row Level Security (optional but recommended)
ALTER TABLE billboards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow all" ON billboards FOR ALL USING (true);
```

5. Go to **Storage** > Create a new bucket named `billboards` (set to **Public**)

---

### 2. Anthropic API Key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Create an API key
3. Add it in the app's Settings tab

---

### 3. Xcode Setup

1. Open `BillboardScanner.xcodeproj` in Xcode
2. Select your **Team** in Signing & Capabilities
3. Change the Bundle Identifier to something unique (e.g., `com.yourname.BillboardScanner`)
4. Connect your iPhone and select it as the build target
5. Build and run (`Cmd + R`)

> **Note:** Camera features require a real device — they won't work in the iOS Simulator.

---

### 4. In-App Configuration

Open the **Settings** tab in the app and enter:
- Your Supabase Project URL
- Your Supabase Anon Key
- Your Anthropic API Key

These are stored securely on-device using `UserDefaults`.

---

## How It Works

```
iPhone camera feed (live)
  └─ Vision framework scans for rectangles
       └─ Billboard detected with >85% confidence
            └─ Photo auto-captured + cropped to billboard bounds
                 └─ CoreLocation stamps GPS coordinates
                      └─ Vision OCR extracts billboard text
                           └─ Saved locally (works offline)
                                └─ When on WiFi → uploads to Supabase Storage
                                     └─ Claude API categorizes the ad text
                                          └─ Record inserted into Supabase DB
                                               └─ Website auto-updates
```

---

## App Tabs

| Tab | Description |
|-----|-------------|
| 📷 Scan | Live camera with detection overlay and auto-capture |
| 🖼 Gallery | Browse all billboards, filter by category, search OCR text |
| 📊 Stats | Category breakdown charts, capture counts, recent activity |
| ⚙️ Settings | API keys, detection sensitivity, data management |

---

## Detection Tuning

In Settings, adjust the **Confidence Threshold**:
- **Higher (90%+)** — Fewer false positives, may miss some billboards
- **Lower (70%)** — Catches more billboards, may capture non-billboard rectangles
- **Recommended** — 85% for highway driving at speed

---

## File Structure

```
BillboardScanner/
├── BillboardScannerApp.swift      # App entry point
├── Info.plist                     # Permissions (camera, location)
├── Models/
│   └── Billboard.swift            # Data model + Supabase DTO
├── Services/
│   ├── CameraService.swift        # AVFoundation + Vision detection
│   ├── LocationService.swift      # CoreLocation GPS
│   └── SupabaseService.swift      # Upload, sync, AI categorization
└── Views/
    ├── ContentView.swift          # Tab navigation
    ├── CameraView.swift           # Live camera + detection overlay
    ├── GalleryView.swift          # Photo gallery + detail view
    ├── StatsView.swift            # Analytics dashboard
    └── SettingsView.swift         # Configuration
```

---

## Requirements

- iOS 16.0+
- Xcode 15+
- iPhone with camera (physical device required)
- Apple Developer account ($99/year) for device testing
- Supabase account (free tier works)
- Anthropic API key (for AI categorization)

---

## Next Steps

- [ ] Build the companion **website** (Next.js + Mapbox) to display all billboards on a map
- [ ] Add **route planning** — define a highway segment to systematically cover
- [ ] Add **duplicate detection** — skip billboards already captured recently
- [ ] Export data as **CSV or GeoJSON**
- [ ] Add **video mode** — capture frames continuously while driving
